"""
tests/test_watermark_remover.py

Unit tests for core/watermark_remover.py, covering both removal
strategies and the safety guarantees around them:

    - a watermark living in its own separate content-stream object
      (Strategy 1) is removed with the real content byte-identical
    - a watermark appended inline into the same stream as real content
      (Strategy 2) is removed without disturbing the real content,
      regardless of internal operator ordering
    - a stream that mixes watermark text with real text is NEVER
      dropped wholesale by Strategy 1 (must fall through to Strategy 2)
    - literal "q"/"Q" letters inside real text are never mistaken for
      graphics-state operators
    - a document with no watermark at all is a safe no-op

Run with: pytest tests/test_watermark_remover.py -v
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest
import fitz  # PyMuPDF

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.watermark_remover import (
    remove_watermark_from_document,
    verify_content_unchanged,
    WatermarkSignature,
)

SIGNATURE = WatermarkSignature(literals=("TESTBANK",))


def _make_separate_stream_pdf(path: Path) -> None:
    """Watermark as its own content-stream object referenced in /Contents."""
    doc = fitz.open()
    page = doc.new_page(width=400, height=400)
    page.insert_text((50, 50), "Body A")
    page.insert_text((50, 300), "Body B")

    watermark_block = (
        b" q\n0.7071068 0.7071068 -0.7071068 0.7071068 200 200 cm\n"
        b"BT\n0.6 0.6 0.6 rg\n/helv 20 Tf\n-100 -5 Td\n"
        b"(TESTBANK 999888 24-07-2026 09:15) Tj\nET\nQ"
    )
    new_xref = doc.get_new_xref()
    doc.update_object(new_xref, "<<>>")
    doc.update_stream(new_xref, watermark_block)
    existing_xrefs = page.get_contents()
    doc.xref_set_key(
        page.xref, "Contents",
        "[" + " ".join(f"{x} 0 R" for x in existing_xrefs) + f" {new_xref} 0 R]",
    )
    doc.save(path)
    doc.close()


def _make_mixed_stream_pdf(path: Path) -> None:
    """Watermark appended into the SAME stream as one real text run."""
    doc = fitz.open()
    page = doc.new_page(width=400, height=400)
    page.insert_text((50, 50), "Real body paragraph one.")
    page.insert_text((50, 300), "Real body paragraph two.")
    xref = page.get_contents()[0]
    existing = doc.xref_stream(xref)
    watermark_block = (
        b" q\nq\n0.7071068 0.7071068 -0.7071068 0.7071068 200 200 cm\n"
        b"BT\n0.6 0.6 0.6 rg\n/helv 20 Tf\n-100 -5 Td\n"
        b"(TESTBANK 999888 24-07-2026 09:15) Tj\nET\nQ\nQ"
    )
    doc.update_stream(xref, existing + watermark_block)
    doc.save(path)
    doc.close()


def _make_q_letters_pdf(path: Path) -> None:
    """Real text containing literal 'q'/'Q' words, plus an inline watermark."""
    doc = fitz.open()
    page = doc.new_page(width=400, height=400)
    page.insert_text((50, 50), "Quarterly quality review: q factor is high.")
    page.insert_text((50, 300), "Another line with Q and q letters scattered around.")
    xref = page.get_contents()[0]
    existing = doc.xref_stream(xref)
    watermark_block = (
        b" q\n0.7071068 0.7071068 -0.7071068 0.7071068 200 200 cm\n"
        b"BT\n0.6 0.6 0.6 rg\n/helv 20 Tf\n-100 -5 Td\n"
        b"(TESTBANK 999888 24-07-2026 09:15) Tj\nET\nQ"
    )
    doc.update_stream(xref, existing + watermark_block)
    doc.save(path)
    doc.close()


def _make_clean_pdf(path: Path) -> None:
    """A document with no watermark at all."""
    doc = fitz.open()
    page = doc.new_page(width=400, height=400)
    page.insert_text((50, 50), "Just a normal document with no watermark.")
    doc.save(path)
    doc.close()


# --------------------------------------------------------------------------
# WatermarkSignature
# --------------------------------------------------------------------------

def test_signature_matches_literal():
    sig = WatermarkSignature(literals=("SAKSHAM",))
    assert sig.matches("PNB SAKSHAM 5135265") is True
    assert sig.matches("Unrelated body text") is False


def test_signature_matches_default_timestamp_pattern():
    sig = WatermarkSignature()
    assert sig.matches("21-07-2026 10:20") is True
    assert sig.matches("No date here") is False


# --------------------------------------------------------------------------
# Strategy 1: separate content stream
# --------------------------------------------------------------------------

def test_separate_stream_watermark_removed(tmp_path):
    src = tmp_path / "separate.pdf"
    out = tmp_path / "separate_clean.pdf"
    _make_separate_stream_pdf(src)

    result = remove_watermark_from_document(src, out, SIGNATURE)

    assert result.success is True
    assert result.pages_cleaned == 1
    assert result.pages_via_separate_stream == 1
    assert result.pages_unmatched == []

    clean_text = fitz.open(out)[0].get_text()
    assert "TESTBANK" not in clean_text
    assert "Body A" in clean_text
    assert "Body B" in clean_text


def test_separate_stream_real_content_byte_identical(tmp_path):
    src = tmp_path / "separate.pdf"
    out = tmp_path / "separate_clean.pdf"
    _make_separate_stream_pdf(src)

    remove_watermark_from_document(src, out, SIGNATURE)

    ok, mismatches = verify_content_unchanged(src, out)
    assert ok is True
    assert mismatches == []


# --------------------------------------------------------------------------
# Strategy 1 safety gate: mixed stream must NOT be dropped wholesale
# --------------------------------------------------------------------------

def test_mixed_stream_does_not_delete_real_content(tmp_path):
    src = tmp_path / "mixed.pdf"
    out = tmp_path / "mixed_clean.pdf"
    _make_mixed_stream_pdf(src)

    result = remove_watermark_from_document(src, out, SIGNATURE)

    assert result.success is True
    assert result.pages_cleaned == 1
    # Must go through the inline-block path, NOT the whole-stream drop,
    # since the stream mixes watermark + real text.
    assert result.pages_via_inline_block == 1
    assert result.pages_via_separate_stream == 0

    clean_text = fitz.open(out)[0].get_text()
    assert "TESTBANK" not in clean_text
    assert "Real body paragraph one." in clean_text
    assert "Real body paragraph two." in clean_text


# --------------------------------------------------------------------------
# Strategy 2 safety: literal q/Q letters in real text must not confuse it
# --------------------------------------------------------------------------

def test_literal_q_letters_in_real_text_are_preserved(tmp_path):
    src = tmp_path / "qletters.pdf"
    out = tmp_path / "qletters_clean.pdf"
    _make_q_letters_pdf(src)

    result = remove_watermark_from_document(src, out, SIGNATURE)

    assert result.success is True
    assert result.pages_cleaned == 1

    clean_text = fitz.open(out)[0].get_text()
    assert "TESTBANK" not in clean_text
    assert "Quarterly quality review" in clean_text
    assert "Another line with Q and q letters" in clean_text


# --------------------------------------------------------------------------
# No watermark present: safe no-op
# --------------------------------------------------------------------------

def test_no_watermark_is_safe_noop(tmp_path):
    src = tmp_path / "clean.pdf"
    out = tmp_path / "clean_out.pdf"
    _make_clean_pdf(src)

    result = remove_watermark_from_document(src, out, SIGNATURE)

    assert result.success is True
    assert result.pages_cleaned == 0
    assert result.pages_unmatched == [1]

    ok, mismatches = verify_content_unchanged(src, out)
    assert ok is True
    assert mismatches == []


# --------------------------------------------------------------------------
# Encrypted PDFs
# --------------------------------------------------------------------------

def test_encrypted_pdf_without_password_fails(tmp_path):
    doc = fitz.open()
    page = doc.new_page(width=200, height=200)
    page.insert_text((20, 20), "Protected content")
    src = tmp_path / "encrypted.pdf"
    doc.save(src, encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw="owner", user_pw="secret")
    doc.close()

    result = remove_watermark_from_document(src, tmp_path / "out.pdf", SIGNATURE)

    assert result.success is False
    assert "password" in (result.error or "").lower() or "encrypt" in (result.error or "").lower()


def test_encrypted_pdf_with_correct_password_succeeds(tmp_path):
    doc = fitz.open()
    page = doc.new_page(width=200, height=200)
    page.insert_text((20, 20), "Protected content")
    src = tmp_path / "encrypted.pdf"
    doc.save(src, encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw="owner", user_pw="secret")
    doc.close()

    result = remove_watermark_from_document(src, tmp_path / "out.pdf", SIGNATURE, password="secret")

    assert result.success is True
