"""
tests/test_core.py

Unit tests for the non-GUI core logic:
    - page selection resolution (core.redactor.resolve_page_indices)
    - region validation and rect conversion
    - profile save/load round-trip (core.profile_manager)
    - output path computation (core.pdf_processor)
    - end-to-end redaction on a generated in-memory PDF (verifies the
      redacted text is actually gone, not just covered)

Run with: pytest tests/test_core.py -v
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest
import fitz  # PyMuPDF

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.redactor import (
    resolve_page_indices,
    _parse_page_spec,
    _region_to_rect,
    apply_profile_to_document,
    EncryptedPDFError,
)
from core.profile_manager import RedactionProfile, RedactionRegion, ProfileManager
from core.pdf_processor import compute_output_path, discover_pdfs, build_queue


# --------------------------------------------------------------------------
# Page selection
# --------------------------------------------------------------------------

def test_resolve_all_pages():
    assert resolve_page_indices("all", "", 5) == [0, 1, 2, 3, 4]


def test_resolve_first_last():
    assert resolve_page_indices("first", "", 10) == [0]
    assert resolve_page_indices("last", "", 10) == [9]


def test_resolve_odd_even():
    assert resolve_page_indices("odd", "", 6) == [0, 2, 4]  # human pages 1,3,5
    assert resolve_page_indices("even", "", 6) == [1, 3, 5]  # human pages 2,4,6


def test_resolve_custom_spec():
    assert resolve_page_indices("custom", "1,3,5", 10) == [0, 2, 4]


def test_resolve_range_spec():
    assert resolve_page_indices("range", "1-3,7-9", 10) == [0, 1, 2, 6, 7, 8]


def test_resolve_range_out_of_bounds_raises():
    with pytest.raises(ValueError):
        _parse_page_spec("1-20", 5)


def test_resolve_empty_spec_raises():
    with pytest.raises(ValueError):
        _parse_page_spec("", 5)


def test_resolve_unknown_selection_raises():
    with pytest.raises(ValueError):
        resolve_page_indices("bogus", "", 5)


def test_resolve_zero_page_document():
    assert resolve_page_indices("all", "", 0) == []


# --------------------------------------------------------------------------
# Region validation and rect conversion
# --------------------------------------------------------------------------

def test_region_validate_ok():
    r = RedactionRegion(x=0.1, y=0.1, width=0.2, height=0.1)
    assert r.validate() is True


def test_region_validate_zero_size_invalid():
    r = RedactionRegion(x=0.1, y=0.1, width=0.0, height=0.1)
    assert r.validate() is False


def test_region_validate_out_of_bounds_invalid():
    r = RedactionRegion(x=1.5, y=0.1, width=0.1, height=0.1)
    assert r.validate() is False


def test_region_to_rect_scaling():
    region = RedactionRegion(x=0.25, y=0.25, width=0.5, height=0.25)
    rect = _region_to_rect(region, page_width=200.0, page_height=100.0, margin=0.0)
    assert rect.x0 == pytest.approx(50.0)
    assert rect.y0 == pytest.approx(25.0)
    assert rect.x1 == pytest.approx(150.0)
    assert rect.y1 == pytest.approx(50.0)


def test_region_to_rect_margin_clamped():
    region = RedactionRegion(x=0.0, y=0.0, width=0.1, height=0.1)
    rect = _region_to_rect(region, page_width=100.0, page_height=100.0, margin=0.5)
    # margin would push x0/y0 negative; must clamp to 0
    assert rect.x0 == 0.0
    assert rect.y0 == 0.0


# --------------------------------------------------------------------------
# Profile save/load round-trip
# --------------------------------------------------------------------------

def test_profile_round_trip(tmp_path):
    manager = ProfileManager(tmp_path)
    profile = RedactionProfile(
        name="Portal A",
        regions=[RedactionRegion(0.1, 0.1, 0.2, 0.05)],
        page_selection="first",
        color=(0.0, 0.0, 0.0),
        opacity=0.8,
        margin=0.01,
    )
    manager.save(profile)
    loaded = manager.load("Portal A")

    assert loaded.name == "Portal A"
    assert loaded.page_selection == "first"
    assert len(loaded.regions) == 1
    assert loaded.regions[0].x == pytest.approx(0.1)
    assert loaded.opacity == pytest.approx(0.8)


def test_profile_list_and_delete(tmp_path):
    manager = ProfileManager(tmp_path)
    manager.save(RedactionProfile(name="P1"))
    manager.save(RedactionProfile(name="P2"))
    assert set(manager.list_profiles()) == {"P1", "P2"}
    manager.delete("P1")
    assert manager.list_profiles() == ["P2"]


def test_profile_load_missing_raises(tmp_path):
    manager = ProfileManager(tmp_path)
    with pytest.raises(FileNotFoundError):
        manager.load("Nonexistent")


# --------------------------------------------------------------------------
# Output path computation
# --------------------------------------------------------------------------

def test_compute_output_path_suffix_mode():
    src = Path("/data/in/report.pdf")
    out = compute_output_path(src, Path("/data/out"), None, "suffix")
    assert out == Path("/data/out/report_redacted.pdf")


def test_compute_output_path_overwrite_mode():
    src = Path("/data/in/report.pdf")
    out = compute_output_path(src, Path("/data/out"), None, "overwrite")
    assert out == Path("/data/out/report.pdf")


def test_compute_output_path_custom_suffix():
    src = Path("/data/in/report.pdf")
    out = compute_output_path(src, Path("/data/out"), None, "custom", custom_suffix="_final")
    assert out == Path("/data/out/report_final.pdf")


def test_compute_output_path_preserves_structure():
    src = Path("/data/in/sub/report.pdf")
    out = compute_output_path(src, Path("/data/out"), Path("/data/in"), "overwrite")
    assert out == Path("/data/out/sub/report.pdf")


# --------------------------------------------------------------------------
# File discovery
# --------------------------------------------------------------------------

def test_discover_pdfs_recursive(tmp_path):
    (tmp_path / "sub").mkdir()
    f1 = tmp_path / "a.pdf"
    f2 = tmp_path / "sub" / "b.pdf"
    f3 = tmp_path / "notes.txt"
    for f in (f1, f2, f3):
        f.write_text("x")

    found = discover_pdfs([tmp_path], recursive=True)
    assert f1.resolve() in found
    assert f2.resolve() in found
    assert f3.resolve() not in found


def test_discover_pdfs_non_recursive(tmp_path):
    (tmp_path / "sub").mkdir()
    f1 = tmp_path / "a.pdf"
    f2 = tmp_path / "sub" / "b.pdf"
    for f in (f1, f2):
        f.write_text("x")

    found = discover_pdfs([tmp_path], recursive=False)
    assert f1.resolve() in found
    assert f2.resolve() not in found


# --------------------------------------------------------------------------
# End-to-end redaction (verifies content is actually removed)
# --------------------------------------------------------------------------

@pytest.fixture
def sample_pdf(tmp_path) -> Path:
    """Create a simple one-page PDF containing a known text string."""
    doc = fitz.open()
    page = doc.new_page(width=200, height=200)
    page.insert_text((20, 20), "SECRET-EMPLOYEE-ID-12345")
    page.insert_text((20, 150), "This text should remain visible.")
    path = tmp_path / "sample.pdf"
    doc.save(path)
    doc.close()
    return path


def test_redaction_removes_text_content(sample_pdf, tmp_path):
    profile = RedactionProfile(
        name="Test",
        # Region roughly covering the top-left text at (20,20) on a 200x200 page.
        regions=[RedactionRegion(x=0.0, y=0.0, width=0.6, height=0.2)],
        page_selection="all",
        color=(0.0, 0.0, 0.0),
    )
    output_path = tmp_path / "sample_redacted.pdf"
    result = apply_profile_to_document(sample_pdf, output_path, profile)

    assert result.success is True
    assert output_path.exists()

    with fitz.open(output_path) as doc:
        full_text = doc[0].get_text()
        assert "SECRET-EMPLOYEE-ID-12345" not in full_text
        assert "This text should remain visible." in full_text


def test_redaction_on_encrypted_pdf_without_password_fails(tmp_path):
    doc = fitz.open()
    page = doc.new_page(width=200, height=200)
    page.insert_text((20, 20), "Protected content")
    src = tmp_path / "encrypted.pdf"
    doc.save(src, encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw="owner", user_pw="secret")
    doc.close()

    profile = RedactionProfile(name="Test", regions=[RedactionRegion(0.0, 0.0, 0.5, 0.2)])
    result = apply_profile_to_document(src, tmp_path / "out.pdf", profile)

    assert result.success is False
    assert "password" in (result.error or "").lower() or "encrypt" in (result.error or "").lower()


def test_redaction_with_correct_password_succeeds(tmp_path):
    doc = fitz.open()
    page = doc.new_page(width=200, height=200)
    page.insert_text((20, 20), "Protected content")
    src = tmp_path / "encrypted.pdf"
    doc.save(src, encryption=fitz.PDF_ENCRYPT_AES_256, owner_pw="owner", user_pw="secret")
    doc.close()

    profile = RedactionProfile(name="Test", regions=[RedactionRegion(0.0, 0.0, 0.5, 0.2)])
    result = apply_profile_to_document(src, tmp_path / "out.pdf", profile, password="secret")

    assert result.success is True


def test_redaction_multipage_selection(tmp_path):
    doc = fitz.open()
    for i in range(4):
        page = doc.new_page(width=200, height=200)
        page.insert_text((20, 20), f"Page {i + 1} secret")
    src = tmp_path / "multi.pdf"
    doc.save(src)
    doc.close()

    profile = RedactionProfile(
        name="Test",
        regions=[RedactionRegion(0.0, 0.0, 0.6, 0.2)],
        page_selection="odd",  # human pages 1 and 3 -> indices 0, 2
    )
    out = tmp_path / "multi_redacted.pdf"
    result = apply_profile_to_document(src, out, profile)

    assert result.success is True
    assert result.pages_processed == 2
    with fitz.open(out) as redacted:
        assert "Page 1 secret" not in redacted[0].get_text()
        assert "Page 2 secret" in redacted[1].get_text()
        assert "Page 3 secret" not in redacted[2].get_text()
        assert "Page 4 secret" in redacted[3].get_text()
