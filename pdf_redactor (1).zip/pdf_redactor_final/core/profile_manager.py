"""
core/profile_manager.py

Data model and persistence for redaction "profiles" — named,
reusable sets of redaction rectangles (e.g. "Portal A", "Portal B")
that a user applies to many PDFs without re-drawing regions each time.

Coordinates are stored as *normalized* fractions (0.0-1.0 of page
width/height) rather than absolute points, so a single profile
applies correctly across pages/documents of different sizes. See
core/pdf_processor.py for the denormalization step.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

from utils.logger import get_logger

logger = get_logger(__name__)

PROFILE_SCHEMA_VERSION = 1


@dataclass
class RedactionRegion:
    """
    A single redaction rectangle, stored in normalized page coordinates.

    x, y: top-left corner as a fraction of page width/height (0-1).
    width, height: size as a fraction of page width/height (0-1).
    """

    x: float
    y: float
    width: float
    height: float

    def to_dict(self) -> dict[str, float]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RedactionRegion":
        return cls(
            x=float(data["x"]),
            y=float(data["y"]),
            width=float(data["width"]),
            height=float(data["height"]),
        )

    def validate(self) -> bool:
        """Basic sanity check: region must be non-degenerate and in-bounds-ish."""
        return (
            0.0 <= self.x <= 1.0
            and 0.0 <= self.y <= 1.0
            and self.width > 0.0
            and self.height > 0.0
        )


@dataclass
class RedactionProfile:
    """
    A named, saveable set of redaction settings.

    page_selection: one of "all", "first", "last", "odd", "even",
        "range", "custom". When "range" or "custom", `page_spec`
        holds the raw spec string (e.g. "1-3,5" or "2,4,9").
    """

    name: str
    regions: list[RedactionRegion] = field(default_factory=list)
    page_selection: str = "all"
    page_spec: str = ""
    color: tuple[float, float, float] = (0.0, 0.0, 0.0)  # RGB 0-1, default black
    opacity: float = 1.0
    margin: float = 0.0  # extra padding around each region, normalized units
    schema_version: int = PROFILE_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["regions"] = [r.to_dict() for r in self.regions]
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RedactionProfile":
        regions = [RedactionRegion.from_dict(r) for r in data.get("regions", [])]
        color = tuple(data.get("color", (0.0, 0.0, 0.0)))  # type: ignore[assignment]
        return cls(
            name=data["name"],
            regions=regions,
            page_selection=data.get("page_selection", "all"),
            page_spec=data.get("page_spec", ""),
            color=color,  # type: ignore[arg-type]
            opacity=float(data.get("opacity", 1.0)),
            margin=float(data.get("margin", 0.0)),
            schema_version=data.get("schema_version", PROFILE_SCHEMA_VERSION),
        )


class ProfileManager:
    """Loads/saves RedactionProfile objects as JSON files on disk."""

    def __init__(self, profiles_dir: Path):
        self.profiles_dir = profiles_dir
        self.profiles_dir.mkdir(parents=True, exist_ok=True)

    def list_profiles(self) -> list[str]:
        """Return profile names available on disk (sorted)."""
        return sorted(p.stem for p in self.profiles_dir.glob("*.json"))

    def _path_for(self, name: str) -> Path:
        safe_name = "".join(c for c in name if c.isalnum() or c in " _-").strip()
        if not safe_name:
            raise ValueError("Profile name must contain at least one valid character.")
        return self.profiles_dir / f"{safe_name}.json"

    def save(self, profile: RedactionProfile) -> Path:
        """Save a profile to disk, overwriting any existing file of the same name."""
        path = self._path_for(profile.name)
        try:
            path.write_text(json.dumps(profile.to_dict(), indent=2), encoding="utf-8")
            logger.info("Saved profile '%s' to %s", profile.name, path)
        except OSError as exc:
            logger.error("Failed to save profile '%s': %s", profile.name, exc)
            raise
        return path

    def load(self, name: str) -> RedactionProfile:
        """Load a profile by name. Raises FileNotFoundError if it does not exist."""
        path = self._path_for(name)
        if not path.exists():
            raise FileNotFoundError(f"Profile '{name}' not found at {path}")
        data = json.loads(path.read_text(encoding="utf-8"))
        return RedactionProfile.from_dict(data)

    def delete(self, name: str) -> None:
        """Delete a profile file if it exists."""
        path = self._path_for(name)
        if path.exists():
            path.unlink()
            logger.info("Deleted profile '%s'", name)
