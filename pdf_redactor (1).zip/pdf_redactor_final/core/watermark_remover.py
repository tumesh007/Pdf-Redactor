"""
core/watermark_remover.py

Removes "download stamp" style text watermarks (e.g. portal stamps that
overlay "<user id> <date> <time>" diagonally across every page) WITHOUT
using area-based redaction rectangles.

Why this module exists (and why rectangles are the wrong tool here):
    A rectangle redaction erases *everything* inside a geometric area -
    it can't tell the difference between "watermark ink" and "real text
    ink" that happen to occupy the same page coordinates. Diagonal
    overlay watermarks are specifically designed to cross over body
    text, so an area-based rectangle big enough to cover the watermark
    will also blank out real paragraph text underneath it - hence the
    "black boxes eating my document" problem.

    The correct fix operates one level lower: at the PDF *content
    stream* level, where the watermark is a specific, identifiable
    drawing instruction (or, commonly, an entirely separate content
    stream object referenced alongside the real one). Removing that
    instruction/stream deletes only the watermark's paint operation and
    never touches the real content's bytes at all.

This module supports two detection/removal strategies, tried in order:

    1. SEPARATE STREAM (most common with portal/download stamping
       tools): the page's /Contents array references more than one
       content stream object, and one of them is entirely dedicated to
       drawing the watermark. Detected by checking each content stream
       object for the watermark signature; removed by re-pointing the
       page's /Contents to only the non-watermark stream(s).

    2. INLINE BLOCK (watermark instructions appended/prepended within
       the same content stream as the real content): detected via a
       structural regex matching the isolated
       `q q <matrix> cm BT <color> rg <alpha gs> <font> Tf <pos> Td
       (<text>) Tj ET Q Q` sequence, gated by a text-content check so
       only instructions whose painted string actually matches the
       watermark signature are removed. Real content drawn before/after
       is untouched because the match is anchored to this exact
       self-contained instruction sequence.

Both strategies verify the *painted text* against a WatermarkSignature
before removing anything - structural shape alone is never sufficient,
so an unrelated rotated stamp (e.g. a legitimate "APPROVED" seal) with
a different string will not be touched.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import fitz  # PyMuPDF

from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class WatermarkSignature:
    """
    Describes what makes a piece of page text "the watermark" rather
    than real content. A match against ANY literal substring OR ANY
    regex pattern is sufficient.

    Defaults are tuned for portal/CBS "download stamp" watermarks that
    show a user/employee ID plus a download date & time
    (e.g. "PNB SAKSHAM 5135265" / "21-07-2026 10:20") - but any bank
    portal's stamp text can be matched by passing custom literals/patterns.
    """

    literals: tuple[str, ...] = ()
    # Default pattern matches common "DD-MM-YYYY HH:MM" download timestamps.
    patterns: tuple[str, ...] = (r"\d{2}[-/]\d{2}[-/]\d{4}\s+\d{2}:\d{2}",)

    def matches(self, text: str) -> bool:
        if any(lit and lit in text for lit in self.literals):
            return True
        return any(re.search(pat, text) for pat in self.patterns)


@dataclass
class WatermarkRemovalResult:
    """Outcome of processing a single PDF file."""

    source_path: Path
    output_path: Path | None
    pages_total: int = 0
    pages_cleaned: int = 0
    pages_via_separate_stream: int = 0
    pages_via_inline_block: int = 0
    pages_unmatched: list[int] = field(default_factory=list)
    success: bool = False
    error: str | None = None


# --------------------------------------------------------------------------
# Strategy 1: separate content-stream removal
# --------------------------------------------------------------------------

def _extract_text_literals(raw: bytes) -> list[str]:
    """
    Extract every text-show operand from a content stream, decoded to
    a best-effort string: both parenthesized literal strings `(...)`
    and hex strings `<...>` (PyMuPDF's own text-insertion helpers, and
    many real-world PDF generators, use hex strings rather than
    parenthesized literals). Decoding is best-effort - good enough to
    tell "is this watermark text or something else", not a full font
    cmap/encoding-aware extraction.
    """
    texts: list[str] = []
    for lit in re.findall(rb"\((?:[^()\\]|\\.)*\)", raw):
        texts.append(_decode_pdf_literal(lit))
    for hexbody in re.findall(rb"<([0-9A-Fa-f\s]+)>", raw):
        cleaned = re.sub(rb"\s+", b"", hexbody)
        if len(cleaned) % 2 != 0:
            continue
        try:
            decoded_bytes = bytes.fromhex(cleaned.decode("ascii"))
        except ValueError:
            continue
        # Hex strings are often 2-bytes-per-glyph (UTF-16BE-ish CID fonts)
        # as well as 1-byte-per-glyph; try both and keep whichever yields
        # more printable characters, since we only need a signature check.
        candidates = [
            decoded_bytes.decode("latin-1", errors="ignore"),
        ]
        if len(decoded_bytes) % 2 == 0:
            try:
                candidates.append(decoded_bytes.decode("utf-16-be", errors="ignore"))
            except UnicodeDecodeError:
                pass
        texts.append(max(candidates, key=lambda s: sum(c.isprintable() for c in s)))
    return texts


def _stream_is_watermark_only(raw: bytes, signature: WatermarkSignature) -> bool:
    """
    True only if EVERY non-blank text literal drawn by this content
    stream matches the watermark signature. This guards against a
    stream that happens to contain the watermark string alongside
    unrelated real text (e.g. a generator that packs several text runs
    into one stream object) - such a mixed stream must NOT be dropped
    wholesale, since that would delete real content along with it.
    """
    texts = _extract_text_literals(raw)
    if not texts:
        return False
    for text in texts:
        if text.strip() == "":
            continue  # pure spacing/kerning artifact, ignore
        if not signature.matches(text):
            return False
    return True


def _strip_via_separate_stream(doc: fitz.Document, page: fitz.Page, signature: WatermarkSignature) -> bool:
    """
    If the page's /Contents references more than one stream object and
    exactly one (or more) of them is watermark-ONLY (see
    `_stream_is_watermark_only`), drop it/them from /Contents and keep
    the rest. Returns True if something was removed.
    """
    xrefs = page.get_contents()
    if len(xrefs) < 2:
        return False

    keep: list[int] = []
    removed_any = False
    for xref in xrefs:
        try:
            raw = doc.xref_stream(xref) or b""
        except Exception:  # noqa: BLE001 - unreadable stream, keep it untouched
            keep.append(xref)
            continue
        if _stream_is_watermark_only(raw, signature):
            removed_any = True
            continue
        keep.append(xref)

    if not removed_any:
        return False
    if not keep:
        # Never leave a page with zero content streams; keep the first
        # original one rather than produce an invalid/blank page.
        keep = [xrefs[0]]

    if len(keep) == 1:
        page.set_contents(keep[0])
    else:
        # Multiple legitimate streams remain: point Contents at an array.
        array_str = "[" + " ".join(f"{x} 0 R" for x in keep) + "]"
        doc.xref_set_key(page.xref, "Contents", array_str)

    return True


# --------------------------------------------------------------------------
# Strategy 2: inline block removal via balanced q/Q stack matching
# --------------------------------------------------------------------------
#
# Rather than pattern-matching one fixed token order (cm, BT, rg, gs, Tf,
# Td...), which breaks the moment a different generator - or PyMuPDF's
# own clean_contents() - reorders/reformats those tokens, this strategy:
#   1. Finds every Tj call whose single parenthesized string argument
#      matches the watermark signature.
#   2. Finds the innermost q...Q save/restore pair that encloses that
#      Tj call, using a proper balanced-stack scan (not a fixed
#      sequence), so it works regardless of internal operator order.
#   3. Removes exactly that q...Q span.
#
# q/Q token-scanning masks out string-literal and hex-string contents
# first, so a stray letter "q"/"Q" inside real text (e.g. "(Quarterly
# Report)") is never mistaken for a graphics-state operator.

_STRING_OR_HEX_RE = re.compile(rb"\((?:[^()\\]|\\.)*\)|<[0-9A-Fa-f\s]*>")
_QQ_TOKEN_RE = re.compile(rb"(?<![A-Za-z0-9])[qQ](?![A-Za-z0-9])")
_TJ_CALL_RE = re.compile(rb"(?P<text>\((?:[^()\\]|\\.)*\))\s*Tj\b")


def _decode_pdf_literal(raw: bytes) -> str:
    """Minimal PDF literal-string unescape, sufficient for signature matching."""
    text = raw[1:-1]  # strip surrounding ( )
    text = text.replace(rb"\(", b"(").replace(rb"\)", b")").replace(rb"\\", b"\\")
    text = text.replace(rb"\r", b"\r").replace(rb"\n", b"\n")
    return text.decode("latin-1", errors="replace")


def _mask_strings(content: bytes) -> bytes:
    """Replace every string/hex-string literal's bytes with '.' placeholders
    (same length, so offsets are preserved) for safe q/Q token scanning."""
    mask = bytearray(content)
    for m in _STRING_OR_HEX_RE.finditer(content):
        for i in range(m.start(), m.end()):
            mask[i] = ord(".")
    return bytes(mask)


def _find_enclosing_qQ_span(masked: bytes, pos: int) -> tuple[int, int] | None:
    """
    Return the (start, end) byte offsets of the innermost q...Q pair
    that encloses `pos`, or None if `pos` isn't inside any balanced
    q/Q region. `masked` must have string/hex literals already blanked
    out via `_mask_strings` so only real operator tokens are seen.
    """
    stack: list[int] = []
    best: tuple[int, int] | None = None
    for tok in _QQ_TOKEN_RE.finditer(masked):
        if tok.group() == b"q":
            stack.append(tok.start())
        else:  # b"Q"
            if not stack:
                continue  # unbalanced Q with no matching q; ignore defensively
            start = stack.pop()
            end = tok.end()
            if start <= pos <= end:
                # Innermost so far = smallest span seen that still contains pos.
                if best is None or (end - start) < (best[1] - best[0]):
                    best = (start, end)
    return best


def _strip_via_inline_block(page: fitz.Page, signature: WatermarkSignature) -> bool:
    """
    Locate every Tj call whose text matches the watermark signature,
    find its innermost enclosing q/Q save-restore block, and remove
    that block. Returns True if anything was removed.

    If the page currently has more than one content stream object
    (and Strategy 1 didn't already resolve it), `clean_contents()` is
    used first to canonicalize them into a single stream so this
    function always has one xref to write back to. This changes
    stream *formatting* (whitespace/operator layout) but is guaranteed
    by PyMuPDF to preserve the page's visual content exactly.
    """
    if len(page.get_contents()) != 1:
        page.clean_contents()

    xref = page.get_contents()[0]
    content = page.read_contents()
    masked = _mask_strings(content)

    spans_to_remove: list[tuple[int, int]] = []
    for tj in _TJ_CALL_RE.finditer(content):
        if not signature.matches(_decode_pdf_literal(tj.group("text"))):
            continue
        span = _find_enclosing_qQ_span(masked, tj.start())
        if span is not None:
            spans_to_remove.append(span)

    if not spans_to_remove:
        return False

    # Merge/dedupe overlapping spans, then remove back-to-front so
    # earlier offsets stay valid as we splice.
    spans_to_remove = sorted(set(spans_to_remove), key=lambda s: s[0], reverse=True)
    new_content = content
    for start, end in spans_to_remove:
        new_content = new_content[:start] + new_content[end:]

    page.parent.update_stream(xref, new_content)
    return True


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------

def remove_watermark_from_document(
    input_path: Path,
    output_path: Path,
    signature: WatermarkSignature | None = None,
    password: str | None = None,
) -> WatermarkRemovalResult:
    """
    Remove the configured text watermark from every page of a PDF and
    save the result as a new file. Never touches unrelated content:
    each strategy only removes bytes it has verified paint the
    watermark's own text.

    :param input_path: source PDF path.
    :param output_path: destination path for the cleaned PDF.
    :param signature: what identifies the watermark; defaults to
        WatermarkSignature() (generic date/time-stamp pattern).
    :param password: optional password for an encrypted PDF the user
        has legitimate access to.
    """
    signature = signature or WatermarkSignature()
    doc: fitz.Document | None = None
    try:
        doc = fitz.open(input_path)

        if doc.is_encrypted:
            if not password or not doc.authenticate(password):
                return WatermarkRemovalResult(
                    input_path, None, success=False,
                    error=f"'{input_path.name}' is password-protected; authentication failed.",
                )

        result = WatermarkRemovalResult(input_path, output_path, pages_total=doc.page_count)

        for pno in range(doc.page_count):
            page = doc[pno]
            if _strip_via_separate_stream(doc, page, signature):
                result.pages_cleaned += 1
                result.pages_via_separate_stream += 1
                continue
            if _strip_via_inline_block(page, signature):
                result.pages_cleaned += 1
                result.pages_via_inline_block += 1
                continue
            result.pages_unmatched.append(pno + 1)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        doc.save(output_path, garbage=4, deflate=True)
        result.success = True

        logger.info(
            "Watermark removal on '%s': %d/%d pages cleaned (%d separate-stream, %d inline); "
            "%d page(s) unmatched.",
            input_path.name, result.pages_cleaned, result.pages_total,
            result.pages_via_separate_stream, result.pages_via_inline_block,
            len(result.pages_unmatched),
        )
        return result

    except fitz.FileDataError as exc:
        logger.error("Corrupted PDF '%s': %s", input_path, exc)
        return WatermarkRemovalResult(input_path, None, success=False, error=f"Corrupted or unsupported PDF: {exc}")
    except Exception as exc:  # noqa: BLE001
        logger.exception("Unexpected error removing watermark from '%s'", input_path)
        return WatermarkRemovalResult(input_path, None, success=False, error=f"Unexpected error: {exc}")
    finally:
        if doc is not None:
            doc.close()


def verify_content_unchanged(original_path: Path, cleaned_path: Path) -> tuple[bool, list[int]]:
    """
    Safety check used by tests (and available to callers): confirms
    that every page's *real* content stream in `cleaned_path` is
    byte-for-byte identical to the corresponding stream in
    `original_path`, proving the removal touched only the watermark.

    :return: (all_match, list_of_mismatched_page_numbers_1_indexed)
    """
    orig = fitz.open(original_path)
    clean = fitz.open(cleaned_path)
    mismatches: list[int] = []
    try:
        for pno in range(min(orig.page_count, clean.page_count)):
            orig_xrefs = orig[pno].get_contents()
            clean_xrefs = clean[pno].get_contents()
            orig_bytes = orig.xref_stream(orig_xrefs[0])
            clean_bytes = clean.xref_stream(clean_xrefs[0])
            if orig_bytes != clean_bytes:
                mismatches.append(pno + 1)
    finally:
        orig.close()
        clean.close()
    return (len(mismatches) == 0, mismatches)
