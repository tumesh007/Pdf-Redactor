"""
core/redactor.py

The actual redaction engine. Responsible ONLY for:
    - resolving which page indices a page_selection spec refers to
    - converting normalized regions into absolute page rectangles
    - burning permanent, flattened opaque rectangles into a PDF page

Explicitly OUT OF SCOPE (by design, per project requirements):
    - reconstructing or inferring hidden/covered content
    - stripping or altering embedded security features, metadata,
      digital signatures, or encryption beyond what is required to
      open a document the user already has permission to open

This module uses PyMuPDF's `add_redact_annot` + `apply_redactions`,
which physically removes the underlying text/image content in the
redacted area (not just draws over it), then draws a solid fill so
nothing is recoverable from the saved file.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import fitz  # PyMuPDF

from core.profile_manager import RedactionProfile, RedactionRegion
from utils.logger import get_logger

logger = get_logger(__name__)


class PDFRedactionError(Exception):
    """Raised for any unrecoverable error while processing a PDF."""


class EncryptedPDFError(PDFRedactionError):
    """Raised when a PDF is password-protected and cannot be opened."""


class CorruptedPDFError(PDFRedactionError):
    """Raised when a PDF fails to parse / is structurally invalid."""


@dataclass
class RedactionResult:
    """Outcome of processing a single PDF file."""

    source_path: Path
    output_path: Path | None
    pages_processed: int
    regions_applied: int
    success: bool
    error: str | None = None


def resolve_page_indices(page_selection: str, page_spec: str, page_count: int) -> list[int]:
    """
    Translate a page_selection keyword (+ optional spec string) into a
    concrete, de-duplicated, sorted list of 0-based page indices.

    :param page_selection: "all" | "first" | "last" | "odd" | "even" |
        "range" | "custom"
    :param page_spec: raw spec for "range"/"custom", e.g. "1-3,5" or "2,4,9"
        (1-based, inclusive, as typically shown to end users).
    :param page_count: total pages in the document.
    :raises ValueError: if page_spec is malformed or out of range.
    """
    if page_count <= 0:
        return []

    selection = page_selection.lower().strip()

    if selection == "all":
        return list(range(page_count))
    if selection == "first":
        return [0]
    if selection == "last":
        return [page_count - 1]
    if selection == "odd":
        # "Odd" refers to 1-based human page numbers (1, 3, 5, ...)
        return [i for i in range(page_count) if (i + 1) % 2 == 1]
    if selection == "even":
        return [i for i in range(page_count) if (i + 1) % 2 == 0]
    if selection in ("range", "custom"):
        return _parse_page_spec(page_spec, page_count)

    raise ValueError(f"Unknown page_selection: {page_selection!r}")


def _parse_page_spec(spec: str, page_count: int) -> list[int]:
    """Parse '1-3,5,7-9' style specs (1-based, inclusive) into 0-based indices."""
    if not spec.strip():
        raise ValueError("Page spec is empty for 'range'/'custom' selection.")

    indices: set[int] = set()
    for chunk in spec.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            start_s, end_s = chunk.split("-", 1)
            start, end = int(start_s), int(end_s)
            if start < 1 or end > page_count or start > end:
                raise ValueError(f"Page range '{chunk}' is out of bounds (1-{page_count}).")
            indices.update(range(start - 1, end))
        else:
            page_num = int(chunk)
            if page_num < 1 or page_num > page_count:
                raise ValueError(f"Page number '{chunk}' is out of bounds (1-{page_count}).")
            indices.add(page_num - 1)

    return sorted(indices)


def _region_to_rect(
    region: RedactionRegion, page_width: float, page_height: float, margin: float
) -> fitz.Rect:
    """Convert a normalized region (+ margin) into an absolute fitz.Rect for a page."""
    x0 = max(0.0, region.x - margin) * page_width
    y0 = max(0.0, region.y - margin) * page_height
    x1 = min(1.0, region.x + region.width + margin) * page_width
    y1 = min(1.0, region.y + region.height + margin) * page_height
    return fitz.Rect(x0, y0, x1, y1)


def apply_profile_to_document(
    input_path: Path,
    output_path: Path,
    profile: RedactionProfile,
    password: str | None = None,
) -> RedactionResult:
    """
    Open a PDF, apply the given profile's redaction regions to the
    selected pages, flatten, and save as a new file.

    :param input_path: source PDF path.
    :param output_path: destination path for the redacted PDF.
    :param profile: RedactionProfile describing regions/pages/color/etc.
    :param password: optional password to open an encrypted PDF that the
        user has legitimate access to.
    :return: RedactionResult summarizing the outcome.
    """
    doc: fitz.Document | None = None
    try:
        doc = fitz.open(input_path)

        if doc.is_encrypted:
            if not password or not doc.authenticate(password):
                raise EncryptedPDFError(
                    f"'{input_path.name}' is password-protected; authentication failed."
                )

        if doc.page_count == 0:
            raise CorruptedPDFError(f"'{input_path.name}' has no pages.")

        page_indices = resolve_page_indices(
            profile.page_selection, profile.page_spec, doc.page_count
        )

        regions_applied = 0
        color = profile.color

        for page_index in page_indices:
            page = doc[page_index]
            page_width, page_height = page.rect.width, page.rect.height

            for region in profile.regions:
                if not region.validate():
                    logger.warning(
                        "Skipping invalid region on page %d of %s", page_index + 1, input_path.name
                    )
                    continue
                rect = _region_to_rect(region, page_width, page_height, profile.margin)
                # add_redact_annot marks the area for permanent removal of
                # underlying content, filled with the chosen opaque color.
                page.add_redact_annot(rect, fill=color)
                regions_applied += 1

            # Burn the redactions into the page content stream. After this
            # call the underlying text/images under each rect are gone —
            # not just visually covered — and only the flat fill remains.
            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        # garbage=4 compacts/deduplicates objects; deflate compresses streams.
        doc.save(output_path, garbage=4, deflate=True)

        logger.info(
            "Redacted '%s' -> '%s' (%d pages, %d regions applied)",
            input_path.name,
            output_path.name,
            len(page_indices),
            regions_applied,
        )

        return RedactionResult(
            source_path=input_path,
            output_path=output_path,
            pages_processed=len(page_indices),
            regions_applied=regions_applied,
            success=True,
        )

    except fitz.FileDataError as exc:
        logger.error("Corrupted PDF '%s': %s", input_path, exc)
        return RedactionResult(input_path, None, 0, 0, False, f"Corrupted or unsupported PDF: {exc}")
    except EncryptedPDFError as exc:
        logger.error(str(exc))
        return RedactionResult(input_path, None, 0, 0, False, str(exc))
    except CorruptedPDFError as exc:
        logger.error(str(exc))
        return RedactionResult(input_path, None, 0, 0, False, str(exc))
    except PermissionError as exc:
        logger.error("Permission denied processing '%s': %s", input_path, exc)
        return RedactionResult(input_path, None, 0, 0, False, f"Permission error: {exc}")
    except ValueError as exc:
        logger.error("Invalid page spec for '%s': %s", input_path, exc)
        return RedactionResult(input_path, None, 0, 0, False, f"Invalid page selection: {exc}")
    except Exception as exc:  # noqa: BLE001 - last-resort guard for batch stability
        logger.exception("Unexpected error processing '%s'", input_path)
        return RedactionResult(input_path, None, 0, 0, False, f"Unexpected error: {exc}")
    finally:
        if doc is not None:
            doc.close()
