"""
core/pdf_processor.py

Orchestrates batch redaction: file/folder discovery, output path
computation (preserving folder structure, rename modes), running the
core redactor over a queue, and rendering page previews as images for
the GUI. This module is the "controller" layer between the GUI and
core/redactor.py + core/profile_manager.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

import fitz  # PyMuPDF
from PIL import Image

from core.profile_manager import RedactionProfile
from core.redactor import RedactionResult, apply_profile_to_document
from utils.logger import get_logger

logger = get_logger(__name__)

RenameMode = str  # "suffix" | "overwrite" | "custom"


@dataclass
class BatchJob:
    """A single file entry in the processing queue."""

    input_path: Path
    output_path: Path
    status: str = "pending"  # pending | processing | done | error
    error: str | None = None


@dataclass
class BatchSummary:
    """Aggregate results after a batch run completes."""

    results: list[RedactionResult] = field(default_factory=list)

    @property
    def succeeded(self) -> int:
        return sum(1 for r in self.results if r.success)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if not r.success)


# --------------------------------------------------------------------------
# File discovery
# --------------------------------------------------------------------------

def discover_pdfs(paths: Iterable[Path], recursive: bool = True) -> list[Path]:
    """
    Expand a mix of file and folder paths into a flat, de-duplicated,
    sorted list of .pdf file paths.

    :param paths: files and/or directories provided by the user
        (drag-and-drop or file dialog).
    :param recursive: whether folders should be scanned recursively.
    """
    found: set[Path] = set()
    for p in paths:
        p = Path(p)
        if p.is_file() and p.suffix.lower() == ".pdf":
            found.add(p.resolve())
        elif p.is_dir():
            pattern = "**/*.pdf" if recursive else "*.pdf"
            for match in p.glob(pattern):
                if match.is_file():
                    found.add(match.resolve())
    return sorted(found)


# --------------------------------------------------------------------------
# Output path computation
# --------------------------------------------------------------------------

def compute_output_path(
    input_path: Path,
    output_root: Path,
    source_root: Path | None,
    rename_mode: RenameMode,
    custom_suffix: str = "_redacted",
) -> Path:
    """
    Compute the destination path for a redacted file.

    :param input_path: original file path.
    :param output_root: base output folder chosen by the user.
    :param source_root: common root of the batch input (used to preserve
        relative folder structure under output_root). If None, the file
        is placed directly under output_root.
    :param rename_mode: "suffix" (filename_redacted.pdf), "overwrite"
        (same filename, will overwrite original if output_root == source
        folder), or "custom" (custom_suffix applied instead of default).
    """
    if source_root is not None:
        try:
            rel_dir = input_path.parent.relative_to(source_root)
        except ValueError:
            rel_dir = Path(".")
    else:
        rel_dir = Path(".")

    target_dir = output_root / rel_dir

    if rename_mode == "overwrite":
        filename = input_path.name
    elif rename_mode == "custom":
        filename = f"{input_path.stem}{custom_suffix}{input_path.suffix}"
    else:  # "suffix" default
        filename = f"{input_path.stem}_redacted{input_path.suffix}"

    return target_dir / filename


# --------------------------------------------------------------------------
# Batch execution
# --------------------------------------------------------------------------

def build_queue(
    input_paths: list[Path],
    output_root: Path,
    rename_mode: RenameMode,
    custom_suffix: str = "_redacted",
    preserve_structure: bool = True,
) -> list[BatchJob]:
    """Build a BatchJob queue with pre-computed output paths."""
    source_root = _common_root(input_paths) if preserve_structure else None
    jobs = []
    for path in input_paths:
        out_path = compute_output_path(path, output_root, source_root, rename_mode, custom_suffix)
        jobs.append(BatchJob(input_path=path, output_path=out_path))
    return jobs


def _common_root(paths: list[Path]) -> Path | None:
    """Find the common parent directory shared by all input paths."""
    if not paths:
        return None
    parents = [p.parent for p in paths]
    common = parents[0]
    for parent in parents[1:]:
        while common not in parent.parents and common != parent:
            if common.parent == common:
                return None
            common = common.parent
    return common


def run_batch(
    jobs: list[BatchJob],
    profile: RedactionProfile,
    progress_callback: Callable[[int, int, BatchJob], None] | None = None,
    password_provider: Callable[[Path], str | None] | None = None,
) -> BatchSummary:
    """
    Execute a batch of redaction jobs sequentially.

    :param jobs: queue built by build_queue().
    :param profile: the RedactionProfile to apply to every job.
    :param progress_callback: optional callable(current_index, total, job)
        invoked before each job starts, so the GUI can update a progress
        bar / status bar without this module knowing about Qt.
    :param password_provider: optional callable(path) -> password|None,
        used if a PDF turns out to be encrypted.
    """
    summary = BatchSummary()
    total = len(jobs)

    for i, job in enumerate(jobs, start=1):
        if progress_callback:
            progress_callback(i, total, job)

        job.status = "processing"
        password = password_provider(job.input_path) if password_provider else None

        result = apply_profile_to_document(job.input_path, job.output_path, profile, password)
        summary.results.append(result)

        job.status = "done" if result.success else "error"
        job.error = result.error

    return summary


# --------------------------------------------------------------------------
# Preview rendering (for the GUI's live preview panel)
# --------------------------------------------------------------------------

def render_page_preview(pdf_path: Path, page_index: int = 0, zoom: float = 1.5) -> Image.Image:
    """
    Render a single PDF page to a PIL Image for GUI display.

    :param pdf_path: path to the PDF file.
    :param page_index: 0-based page index to render.
    :param zoom: rendering scale factor (1.5 ~= 108 DPI-equivalent at
        standard page size; GUI applies its own further zoom on top).
    :raises IndexError: if page_index is out of range.
    """
    with fitz.open(pdf_path) as doc:
        if page_index < 0 or page_index >= doc.page_count:
            raise IndexError(f"Page {page_index} out of range (0-{doc.page_count - 1}).")
        page = doc[page_index]
        matrix = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=matrix, alpha=False)
        mode = "RGB"
        return Image.frombytes(mode, (pix.width, pix.height), pix.samples)


def get_page_size(pdf_path: Path, page_index: int = 0) -> tuple[float, float]:
    """Return (width, height) in PDF points for a given page."""
    with fitz.open(pdf_path) as doc:
        page = doc[page_index]
        return page.rect.width, page.rect.height


def get_page_count(pdf_path: Path) -> int:
    """Return total page count of a PDF."""
    with fitz.open(pdf_path) as doc:
        return doc.page_count
