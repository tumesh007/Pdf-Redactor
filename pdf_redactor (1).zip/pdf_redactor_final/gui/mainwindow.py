"""
gui/mainwindow.py

Main application window. Wires together:
    - gui/preview.py (region drawing/editing on the current page)
    - gui/dialogs.py (preferences, profile management)
    - core/pdf_processor.py (batch discovery/execution)
    - core/redactor.py (single-document redaction, via pdf_processor)
    - utils/config.py, utils/logger.py

Batch runs execute on a background QThread (BatchWorker) so the GUI
stays responsive and the progress bar / status bar update live.
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal, QObject
from PySide6.QtGui import QAction, QKeySequence, QUndoStack, QPixmap, QDragEnterEvent, QDropEvent
from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QSplitter,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QLabel,
    QFileDialog,
    QProgressBar,
    QStatusBar,
    QToolBar,
    QMessageBox,
    QInputDialog,
    QCheckBox,
)

from core.pdf_processor import (
    discover_pdfs,
    build_queue,
    run_batch,
    render_page_preview,
    get_page_count,
    BatchJob,
)
from core.profile_manager import (
    ProfileManager,
    RedactionProfile,
    RedactionRegion,
)
from core.redactor import PDFRedactionError
from core.watermark_remover import remove_watermark_from_document, WatermarkSignature
from gui.preview import PreviewScene, PreviewView, pil_to_qpixmap, NormalizedRect
from gui.dialogs import PreferencesDialog, ProfileDialog, show_error, show_warning
from utils.config import AppConfig
from utils.logger import get_logger

logger = get_logger(__name__)

DARK_STYLESHEET = """
QWidget { background-color: #2b2b2b; color: #e0e0e0; }
QListWidget, QLineEdit, QComboBox, QDoubleSpinBox { background-color: #3a3a3a; border: 1px solid #555; }
QPushButton { background-color: #454545; border: 1px solid #666; padding: 5px 10px; border-radius: 3px; }
QPushButton:hover { background-color: #545454; }
QToolBar { background-color: #333; border: none; }
QProgressBar { border: 1px solid #555; text-align: center; }
QProgressBar::chunk { background-color: #5a8fd6; }
"""

LIGHT_STYLESHEET = ""  # Qt Fusion default light palette; explicit light QSS kept minimal.


class BatchWorker(QObject):
    """Runs run_batch() on a background thread and reports progress via signals."""

    progress = Signal(int, int, str)  # current, total, filename
    finished = Signal(object)  # BatchSummary
    error = Signal(str)

    def __init__(self, jobs: list[BatchJob], profile: RedactionProfile):
        super().__init__()
        self.jobs = jobs
        self.profile = profile

    def run(self) -> None:
        try:
            def on_progress(current, total, job):
                self.progress.emit(current, total, job.input_path.name)

            summary = run_batch(self.jobs, self.profile, progress_callback=on_progress)
            self.finished.emit(summary)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Batch worker crashed")
            self.error.emit(str(exc))


class WatermarkWorker(QObject):
    """
    Runs remove_watermark_from_document() over a batch queue on a
    background thread. Kept separate from BatchWorker because it
    calls a different core entry point (no RedactionProfile/regions
    involved - watermark removal needs only a WatermarkSignature).
    """

    progress = Signal(int, int, str)  # current, total, filename
    finished = Signal(list)  # list[WatermarkRemovalResult]
    error = Signal(str)

    def __init__(self, jobs: list[BatchJob], signature: WatermarkSignature):
        super().__init__()
        self.jobs = jobs
        self.signature = signature

    def run(self) -> None:
        try:
            results = []
            total = len(self.jobs)
            for i, job in enumerate(self.jobs, start=1):
                self.progress.emit(i, total, job.input_path.name)
                result = remove_watermark_from_document(job.input_path, job.output_path, self.signature)
                job.status = "done" if result.success else "error"
                job.error = result.error
                results.append(result)
            self.finished.emit(results)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Watermark worker crashed")
            self.error.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self, config: AppConfig, profiles_dir: Path):
        super().__init__()
        self.setWindowTitle("PDF Redactor")
        self.resize(1280, 800)
        self.setAcceptDrops(True)

        self.config = config
        self.profile_manager = ProfileManager(profiles_dir)
        self.current_profile = RedactionProfile(name="Untitled")
        self.input_files: list[Path] = []
        self.current_preview_path: Path | None = None

        self.undo_stack = QUndoStack(self)

        self._build_ui()
        self._build_menu_and_shortcuts()
        self.apply_theme(config.theme)

        self._thread: QThread | None = None
        self._worker: BatchWorker | None = None

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        central = QWidget()
        root_layout = QHBoxLayout(central)

        splitter = QSplitter(Qt.Horizontal)

        # --- left panel: file queue -------------------------------------
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.addWidget(QLabel("Batch Queue"))

        self.file_list = QListWidget()
        self.file_list.itemClicked.connect(self._on_file_selected)
        left_layout.addWidget(self.file_list)

        add_files_btn = QPushButton("Add Files…")
        add_files_btn.clicked.connect(self.add_files_dialog)
        add_folder_btn = QPushButton("Add Folder…")
        add_folder_btn.clicked.connect(self.add_folder_dialog)
        remove_btn = QPushButton("Remove Selected")
        remove_btn.clicked.connect(self.remove_selected_file)
        left_layout.addWidget(add_files_btn)
        left_layout.addWidget(add_folder_btn)
        left_layout.addWidget(remove_btn)

        self.recursive_check = QCheckBox("Recursive folder scan")
        self.recursive_check.setChecked(True)
        left_layout.addWidget(self.recursive_check)

        splitter.addWidget(left_panel)

        # --- center panel: preview -----------------------------------
        center_panel = QWidget()
        center_layout = QVBoxLayout(center_panel)

        toolbar_row = QHBoxLayout()
        zoom_in_btn = QPushButton("Zoom In")
        zoom_out_btn = QPushButton("Zoom Out")
        fit_width_btn = QPushButton("Fit Width")
        fit_page_btn = QPushButton("Fit Page")
        for btn, handler in [
            (zoom_in_btn, self._zoom_in),
            (zoom_out_btn, self._zoom_out),
            (fit_width_btn, self._fit_width),
            (fit_page_btn, self._fit_page),
        ]:
            btn.clicked.connect(handler)
            toolbar_row.addWidget(btn)
        center_layout.addLayout(toolbar_row)

        self.preview_scene = PreviewScene(self.undo_stack)
        self.preview_view = PreviewView(self.preview_scene)
        center_layout.addWidget(self.preview_view)

        splitter.addWidget(center_panel)

        # --- right panel: profile/settings summary --------------------
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.addWidget(QLabel("Active Profile"))
        self.profile_label = QLabel(self.current_profile.name)
        right_layout.addWidget(self.profile_label)

        manage_profiles_btn = QPushButton("Manage Profiles…")
        manage_profiles_btn.clicked.connect(self.open_profile_dialog)
        right_layout.addWidget(manage_profiles_btn)

        delete_rect_btn = QPushButton("Delete Selected Rectangle")
        delete_rect_btn.clicked.connect(self.preview_scene.delete_selected)
        right_layout.addWidget(delete_rect_btn)

        clear_rects_btn = QPushButton("Clear All Rectangles")
        clear_rects_btn.clicked.connect(self.preview_scene.clear_rectangles)
        right_layout.addWidget(clear_rects_btn)

        right_layout.addStretch()

        output_btn = QPushButton("Choose Output Folder…")
        output_btn.clicked.connect(self._choose_output_folder)
        right_layout.addWidget(output_btn)
        self.output_label = QLabel(self.config.default_output_folder)
        self.output_label.setWordWrap(True)
        right_layout.addWidget(self.output_label)

        run_btn = QPushButton("Run Batch Redaction")
        run_btn.setObjectName("runBatchButton")
        run_btn.setToolTip("Draw rectangles on the preview first - covers selected areas opaquely.")
        run_btn.clicked.connect(self.run_batch_clicked)
        right_layout.addWidget(run_btn)

        watermark_btn = QPushButton("Remove Text Watermark…")
        watermark_btn.setObjectName("removeWatermarkButton")
        watermark_btn.setToolTip(
            "For portal/download-stamp watermarks (user ID + date/time overlay).\n"
            "Surgically deletes the watermark's own drawing instructions instead\n"
            "of covering an area - no black boxes, real text is never touched."
        )
        watermark_btn.clicked.connect(self.remove_watermark_clicked)
        right_layout.addWidget(watermark_btn)

        splitter.addWidget(right_panel)
        splitter.setSizes([250, 700, 250])

        root_layout.addWidget(splitter)
        self.setCentralWidget(central)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        status = QStatusBar()
        status.addPermanentWidget(self.progress_bar)
        self.setStatusBar(status)
        self.status_message("Ready.")

    def _build_menu_and_shortcuts(self) -> None:
        menu_bar = self.menuBar()

        file_menu = menu_bar.addMenu("&File")
        open_action = QAction("Add Files…", self)
        open_action.setShortcut(QKeySequence.Open)  # Ctrl+O
        open_action.triggered.connect(self.add_files_dialog)
        file_menu.addAction(open_action)

        save_action = QAction("Run Batch (Save)", self)
        save_action.setShortcut(QKeySequence.Save)  # Ctrl+S
        save_action.triggered.connect(self.run_batch_clicked)
        file_menu.addAction(save_action)

        save_profile_action = QAction("Save Profile As…", self)
        save_profile_action.setShortcut(QKeySequence.SaveAs)  # Ctrl+Shift+S
        save_profile_action.triggered.connect(self.open_profile_dialog)
        file_menu.addAction(save_profile_action)

        prefs_action = QAction("Preferences…", self)
        prefs_action.triggered.connect(self.open_preferences_dialog)
        file_menu.addAction(prefs_action)

        edit_menu = menu_bar.addMenu("&Edit")
        undo_action = self.undo_stack.createUndoAction(self, "Undo")
        undo_action.setShortcut(QKeySequence.Undo)  # Ctrl+Z
        redo_action = self.undo_stack.createRedoAction(self, "Redo")
        redo_action.setShortcut(QKeySequence.Redo)  # Ctrl+Y / Ctrl+Shift+Z
        edit_menu.addAction(undo_action)
        edit_menu.addAction(redo_action)

        delete_action = QAction("Delete Rectangle", self)
        delete_action.setShortcut(QKeySequence.Delete)
        delete_action.triggered.connect(self.preview_scene.delete_selected)
        edit_menu.addAction(delete_action)

        view_menu = menu_bar.addMenu("&View")
        theme_action = QAction("Toggle Theme", self)
        theme_action.triggered.connect(self.toggle_theme)
        view_menu.addAction(theme_action)

    # ------------------------------------------------------------------
    # File queue management
    # ------------------------------------------------------------------

    def add_files_dialog(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "Select PDF files", "", "PDF Files (*.pdf)")
        if files:
            self._add_paths([Path(f) for f in files])

    def add_folder_dialog(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select folder containing PDFs")
        if folder:
            self._add_paths([Path(folder)])

    def _add_paths(self, paths: list[Path]) -> None:
        new_files = discover_pdfs(paths, recursive=self.recursive_check.isChecked())
        added = 0
        for f in new_files:
            if f not in self.input_files:
                self.input_files.append(f)
                self.file_list.addItem(QListWidgetItem(str(f)))
                self.config.add_recent_file(str(f))
                added += 1
        self.status_message(f"Added {added} file(s). Queue: {len(self.input_files)} file(s).")
        if not self.current_preview_path and self.input_files:
            self._load_preview(self.input_files[0])

    def remove_selected_file(self) -> None:
        row = self.file_list.currentRow()
        if row >= 0:
            self.file_list.takeItem(row)
            del self.input_files[row]

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:
        paths = [Path(url.toLocalFile()) for url in event.mimeData().urls()]
        self._add_paths(paths)

    def _on_file_selected(self, item: QListWidgetItem) -> None:
        self._load_preview(Path(item.text()))

    # ------------------------------------------------------------------
    # Preview
    # ------------------------------------------------------------------

    def _load_preview(self, path: Path) -> None:
        try:
            image = render_page_preview(path, page_index=0)
            pixmap = pil_to_qpixmap(image)
            page_count = get_page_count(path)
            self.preview_scene.set_page(pixmap, pixmap.width(), pixmap.height())
            self.current_preview_path = path
            self.status_message(f"Previewing '{path.name}' ({page_count} page(s)).")
        except PDFRedactionError as exc:
            show_error(self, "Preview Failed", str(exc))
        except Exception as exc:  # noqa: BLE001
            logger.exception("Failed to render preview for %s", path)
            show_error(self, "Preview Failed", f"Could not render preview: {exc}")

    def _zoom_in(self) -> None:
        self.preview_view.zoom_in()

    def _zoom_out(self) -> None:
        self.preview_view.zoom_out()

    def _fit_width(self) -> None:
        self.preview_view.fit_width()

    def _fit_page(self) -> None:
        self.preview_view.fit_page()

    # ------------------------------------------------------------------
    # Profiles / preferences
    # ------------------------------------------------------------------

    def open_profile_dialog(self) -> None:
        # Sync current on-screen rectangles into the profile before opening,
        # so "Save Profile" captures what's currently drawn.
        normalized = self.preview_scene.get_normalized_rectangles()
        self.current_profile.regions = [
            RedactionRegion(r.x, r.y, r.width, r.height) for r in normalized
        ]
        dialog = ProfileDialog(self.profile_manager, self.current_profile, self)
        if dialog.exec() and dialog.result_profile:
            self.current_profile = dialog.result_profile
            self.profile_label.setText(self.current_profile.name)
            self.preview_scene.rect_color = self._qcolor_from_profile()
            regions = [
                NormalizedRect(r.x, r.y, r.width, r.height) for r in self.current_profile.regions
            ]
            self.preview_scene.load_normalized_rectangles(regions)
            self.status_message(f"Profile '{self.current_profile.name}' active.")

    def _qcolor_from_profile(self):
        from PySide6.QtGui import QColor
        r, g, b = self.current_profile.color
        return QColor.fromRgbF(r, g, b)

    def open_preferences_dialog(self) -> None:
        dialog = PreferencesDialog(self.config, self)
        if dialog.exec():
            dialog.apply_to_config()
            self.config.save()
            self.output_label.setText(self.config.default_output_folder)
            self.apply_theme(self.config.theme)

    def _choose_output_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select output folder", self.config.default_output_folder)
        if folder:
            self.config.default_output_folder = folder
            self.output_label.setText(folder)

    # ------------------------------------------------------------------
    # Theme
    # ------------------------------------------------------------------

    def apply_theme(self, theme: str) -> None:
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance()
        if theme == "dark":
            app.setStyleSheet(DARK_STYLESHEET)
        else:
            app.setStyleSheet(LIGHT_STYLESHEET)
        self.config.theme = theme

    def toggle_theme(self) -> None:
        self.apply_theme("light" if self.config.theme == "dark" else "dark")

    # ------------------------------------------------------------------
    # Batch execution
    # ------------------------------------------------------------------

    def run_batch_clicked(self) -> None:
        if not self.input_files:
            show_warning(self, "No Files", "Add at least one PDF file or folder before running.")
            return

        # Capture the currently-drawn rectangles from the preview into the profile.
        normalized = self.preview_scene.get_normalized_rectangles()
        self.current_profile.regions = [
            RedactionRegion(r.x, r.y, r.width, r.height) for r in normalized
        ]
        if not self.current_profile.regions:
            show_warning(self, "No Regions", "Draw at least one redaction rectangle before running.")
            return

        output_root = Path(self.output_label.text())
        jobs = build_queue(
            self.input_files,
            output_root,
            rename_mode=self.config.default_rename_mode,
            custom_suffix=self.config.default_suffix,
        )

        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setMaximum(len(jobs))

        self._thread = QThread()
        self._worker = BatchWorker(jobs, self.current_profile)
        self._worker.moveToThread(self._thread)

        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self._on_batch_progress)
        self._worker.finished.connect(self._on_batch_finished)
        self._worker.error.connect(self._on_batch_error)
        self._worker.finished.connect(self._thread.quit)
        self._worker.error.connect(self._thread.quit)

        self._thread.start()

    def _on_batch_progress(self, current: int, total: int, filename: str) -> None:
        self.progress_bar.setValue(current)
        self.status_message(f"Processing {current}/{total}: {filename}")

    def _on_batch_finished(self, summary) -> None:
        self.progress_bar.setVisible(False)
        self.status_message(f"Done. {summary.succeeded} succeeded, {summary.failed} failed.")
        if summary.failed:
            failures = "\n".join(
                f"- {r.source_path.name}: {r.error}" for r in summary.results if not r.success
            )
            show_warning(self, "Batch Completed With Errors", f"{summary.failed} file(s) failed:\n{failures}")
        else:
            QMessageBox.information(self, "Batch Complete", f"All {summary.succeeded} file(s) redacted successfully.")

    def _on_batch_error(self, message: str) -> None:
        self.progress_bar.setVisible(False)
        show_error(self, "Batch Failed", message)

    # ------------------------------------------------------------------
    # Watermark removal (separate from rectangle redaction - see
    # core/watermark_remover.py for why these use different techniques)
    # ------------------------------------------------------------------

    def remove_watermark_clicked(self) -> None:
        if not self.input_files:
            show_warning(self, "No Files", "Add at least one PDF file or folder before running.")
            return

        literal, ok = QInputDialog.getText(
            self,
            "Remove Text Watermark",
            "Text that identifies the watermark (e.g. a portal name like \"SAKSHAM\").\n"
            "Leave blank to match only by date/time-stamp pattern (DD-MM-YYYY HH:MM):",
        )
        if not ok:
            return

        signature = WatermarkSignature(literals=(literal.strip(),)) if literal.strip() else WatermarkSignature()

        output_root = Path(self.output_label.text())
        jobs = build_queue(
            self.input_files,
            output_root,
            rename_mode=self.config.default_rename_mode,
            custom_suffix=self.config.default_suffix,
        )

        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setMaximum(len(jobs))

        self._thread = QThread()
        self._worker = WatermarkWorker(jobs, signature)
        self._worker.moveToThread(self._thread)

        self._thread.started.connect(self._worker.run)
        self._worker.progress.connect(self._on_batch_progress)
        self._worker.finished.connect(self._on_watermark_finished)
        self._worker.error.connect(self._on_batch_error)
        self._worker.finished.connect(self._thread.quit)
        self._worker.error.connect(self._thread.quit)

        self._thread.start()

    def _on_watermark_finished(self, results: list) -> None:
        self.progress_bar.setVisible(False)
        succeeded = [r for r in results if r.success]
        failed = [r for r in results if not r.success]
        unmatched_pages_total = sum(len(r.pages_unmatched) for r in succeeded)

        self.status_message(f"Watermark removal done. {len(succeeded)} succeeded, {len(failed)} failed.")

        lines = [f"{len(succeeded)}/{len(results)} file(s) processed successfully."]
        if unmatched_pages_total:
            lines.append(
                f"{unmatched_pages_total} page(s) across these files had no watermark match - "
                "please spot-check those (the file was still saved unchanged for those pages)."
            )
        if failed:
            lines.append("Failed:\n" + "\n".join(f"- {r.source_path.name}: {r.error}" for r in failed))
            show_warning(self, "Watermark Removal Completed With Errors", "\n\n".join(lines))
        else:
            QMessageBox.information(self, "Watermark Removal Complete", "\n\n".join(lines))

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def status_message(self, message: str) -> None:
        self.statusBar().showMessage(message, 5000)
        logger.info(message)

    def closeEvent(self, event) -> None:
        self.config.save()
        super().closeEvent(event)
