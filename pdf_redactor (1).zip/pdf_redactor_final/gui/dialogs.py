"""
gui/dialogs.py

Modal dialogs used by the main window:
    - PreferencesDialog: theme, default output folder, autosave profiles
    - ProfileDialog: name/save/load/delete profiles, page selection,
      color, opacity, margin
    - PageSelectionWidget: reusable page-selection control (all/first/
      last/odd/even/range/custom) embedded in ProfileDialog
    - show_error(...): consistent error dialog helper for core exceptions
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QFormLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QComboBox,
    QCheckBox,
    QFileDialog,
    QDialogButtonBox,
    QColorDialog,
    QDoubleSpinBox,
    QMessageBox,
    QListWidget,
    QWidget,
)
from PySide6.QtGui import QColor

from utils.config import AppConfig
from core.profile_manager import ProfileManager, RedactionProfile


class PreferencesDialog(QDialog):
    """Edit persistent application preferences (utils.config.AppConfig)."""

    def __init__(self, config: AppConfig, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Preferences")
        self.config = config

        layout = QFormLayout(self)

        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["dark", "light"])
        self.theme_combo.setCurrentText(config.theme)
        layout.addRow("Theme:", self.theme_combo)

        output_row = QHBoxLayout()
        self.output_edit = QLineEdit(config.default_output_folder)
        browse_btn = QPushButton("Browse…")
        browse_btn.clicked.connect(self._browse_output)
        output_row.addWidget(self.output_edit)
        output_row.addWidget(browse_btn)
        layout.addRow("Default output folder:", output_row)

        self.autosave_check = QCheckBox()
        self.autosave_check.setChecked(config.autosave_profiles)
        layout.addRow("Autosave profiles:", self.autosave_check)

        self.rename_combo = QComboBox()
        self.rename_combo.addItems(["suffix", "overwrite", "custom"])
        self.rename_combo.setCurrentText(config.default_rename_mode)
        layout.addRow("Default rename mode:", self.rename_combo)

        self.suffix_edit = QLineEdit(config.default_suffix)
        layout.addRow("Custom suffix:", self.suffix_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def _browse_output(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select default output folder", self.output_edit.text())
        if folder:
            self.output_edit.setText(folder)

    def apply_to_config(self) -> None:
        """Write dialog values back into the AppConfig instance."""
        self.config.theme = self.theme_combo.currentText()
        self.config.default_output_folder = self.output_edit.text()
        self.config.autosave_profiles = self.autosave_check.isChecked()
        self.config.default_rename_mode = self.rename_combo.currentText()
        self.config.default_suffix = self.suffix_edit.text()


class PageSelectionWidget(QWidget):
    """Reusable page-selection control: keyword combo + free-text spec field."""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.combo = QComboBox()
        self.combo.addItems(["all", "first", "last", "odd", "even", "range", "custom"])
        self.spec_edit = QLineEdit()
        self.spec_edit.setPlaceholderText("e.g. 1-3,5,7-9")
        self.combo.currentTextChanged.connect(self._on_mode_changed)
        self._on_mode_changed(self.combo.currentText())

        layout.addWidget(self.combo)
        layout.addWidget(self.spec_edit)

    def _on_mode_changed(self, mode: str) -> None:
        self.spec_edit.setEnabled(mode in ("range", "custom"))

    def get_selection(self) -> tuple[str, str]:
        return self.combo.currentText(), self.spec_edit.text()

    def set_selection(self, selection: str, spec: str) -> None:
        self.combo.setCurrentText(selection)
        self.spec_edit.setText(spec)


class ProfileDialog(QDialog):
    """
    Manage redaction profiles: list existing profiles, load one into
    the current session, or save the current session's settings
    (regions come from the preview scene — this dialog handles the
    metadata: name, page selection, color, opacity, margin).
    """

    def __init__(self, profile_manager: ProfileManager, current_profile: RedactionProfile, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Redaction Profiles")
        self.profile_manager = profile_manager
        self.result_profile: RedactionProfile | None = None

        layout = QVBoxLayout(self)

        self.profile_list = QListWidget()
        self.profile_list.addItems(self.profile_manager.list_profiles())
        self.profile_list.itemDoubleClicked.connect(self._load_selected)
        layout.addWidget(QLabel("Saved profiles:"))
        layout.addWidget(self.profile_list)

        form = QFormLayout()
        self.name_edit = QLineEdit(current_profile.name)
        form.addRow("Profile name:", self.name_edit)

        self.page_selector = PageSelectionWidget()
        self.page_selector.set_selection(current_profile.page_selection, current_profile.page_spec)
        form.addRow("Pages:", self.page_selector)

        color_row = QHBoxLayout()
        self._color = QColor.fromRgbF(*current_profile.color)
        self.color_preview = QLabel()
        self.color_preview.setFixedSize(24, 24)
        self._update_color_preview()
        color_btn = QPushButton("Choose color…")
        color_btn.clicked.connect(self._choose_color)
        color_row.addWidget(self.color_preview)
        color_row.addWidget(color_btn)
        form.addRow("Fill color:", color_row)

        self.opacity_spin = QDoubleSpinBox()
        self.opacity_spin.setRange(0.1, 1.0)
        self.opacity_spin.setSingleStep(0.05)
        self.opacity_spin.setValue(current_profile.opacity)
        form.addRow("Opacity:", self.opacity_spin)

        self.margin_spin = QDoubleSpinBox()
        self.margin_spin.setRange(0.0, 0.1)
        self.margin_spin.setSingleStep(0.005)
        self.margin_spin.setDecimals(3)
        self.margin_spin.setValue(current_profile.margin)
        form.addRow("Margin (fraction of page):", self.margin_spin)

        layout.addLayout(form)

        btn_row = QHBoxLayout()
        load_btn = QPushButton("Load Selected")
        load_btn.clicked.connect(self._load_selected)
        delete_btn = QPushButton("Delete Selected")
        delete_btn.clicked.connect(self._delete_selected)
        btn_row.addWidget(load_btn)
        btn_row.addWidget(delete_btn)
        layout.addLayout(btn_row)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("Save Profile")
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._current_profile = current_profile

    def _update_color_preview(self) -> None:
        self.color_preview.setStyleSheet(f"background-color: {self._color.name()}; border: 1px solid #888;")

    def _choose_color(self) -> None:
        color = QColorDialog.getColor(self._color, self, "Choose redaction fill color")
        if color.isValid():
            self._color = color
            self._update_color_preview()

    def _load_selected(self) -> None:
        item = self.profile_list.currentItem()
        if not item:
            return
        try:
            profile = self.profile_manager.load(item.text())
        except FileNotFoundError as exc:
            show_error(self, "Load Profile Failed", str(exc))
            return
        self.result_profile = profile
        self.accept()

    def _delete_selected(self) -> None:
        item = self.profile_list.currentItem()
        if not item:
            return
        confirm = QMessageBox.question(
            self, "Delete Profile", f"Delete profile '{item.text()}'? This cannot be undone."
        )
        if confirm == QMessageBox.Yes:
            self.profile_manager.delete(item.text())
            self.profile_list.takeItem(self.profile_list.row(item))

    def _save(self) -> None:
        name = self.name_edit.text().strip()
        if not name:
            show_error(self, "Invalid Name", "Profile name cannot be empty.")
            return
        page_selection, page_spec = self.page_selector.get_selection()
        profile = RedactionProfile(
            name=name,
            regions=self._current_profile.regions,  # regions injected by caller before opening dialog
            page_selection=page_selection,
            page_spec=page_spec,
            color=(self._color.redF(), self._color.greenF(), self._color.blueF()),
            opacity=self.opacity_spin.value(),
            margin=self.margin_spin.value(),
        )
        try:
            self.profile_manager.save(profile)
        except (OSError, ValueError) as exc:
            show_error(self, "Save Profile Failed", str(exc))
            return
        self.result_profile = profile
        self.accept()


def show_error(parent, title: str, message: str) -> None:
    """Consistent error dialog for core.redactor exceptions and validation failures."""
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Critical)
    box.setWindowTitle(title)
    box.setText(message)
    box.exec()


def show_warning(parent, title: str, message: str) -> None:
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Warning)
    box.setWindowTitle(title)
    box.setText(message)
    box.exec()
