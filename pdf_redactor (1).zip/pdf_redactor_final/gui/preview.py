"""
gui/preview.py

Interactive PDF page preview built on QGraphicsView/QGraphicsScene.

Responsibilities:
    - Render a PDF page as the scene background.
    - Let the user draw, move, resize, and delete redaction rectangles.
    - Track rectangle edits on an undo/redo stack (QUndoStack).
    - Provide zoom (in/out/fit-width/fit-page) and pan (space+drag,
      middle-mouse-drag, ctrl+wheel).
    - Expose rectangles in *normalized* page coordinates (0-1) so they
      are resolution-independent and reusable across pages/documents,
      matching core.profile_manager.RedactionRegion.

This module is GUI-only: it has no knowledge of PDF redaction logic.
It hands normalized rectangles up to gui/mainwindow.py, which builds a
RedactionProfile and calls into core/.
"""

from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import QRectF, Qt, Signal, QPointF
from PySide6.QtGui import (
    QPixmap,
    QImage,
    QPen,
    QBrush,
    QColor,
    QUndoStack,
    QUndoCommand,
    QCursor,
)
from PySide6.QtWidgets import (
    QGraphicsScene,
    QGraphicsView,
    QGraphicsRectItem,
    QGraphicsPixmapItem,
    QGraphicsItem,
)

from PIL.ImageQt import ImageQt

HANDLE_SIZE = 8
MIN_RECT_SIZE = 6  # pixels, in scene coordinates, to avoid accidental 0-size rects


def pil_to_qpixmap(pil_image) -> QPixmap:
    """Convert a PIL Image into a QPixmap for scene display."""
    qimage = ImageQt(pil_image)
    return QPixmap.fromImage(QImage(qimage))


class RedactionRectItem(QGraphicsRectItem):
    """
    A movable, resizable rectangle representing one redaction region.

    Resizing is done via a simple corner-drag: when the mouse is near
    the bottom-right corner, drag events resize instead of move.
    """

    def __init__(self, rect: QRectF, color: QColor, opacity: float = 0.55):
        super().__init__(rect)
        self.setFlags(
            QGraphicsItem.ItemIsMovable
            | QGraphicsItem.ItemIsSelectable
            | QGraphicsItem.ItemSendsGeometryChanges
        )
        self.setAcceptHoverEvents(True)
        self._resizing = False
        self._press_rect: QRectF | None = None
        self._press_pos: QPointF | None = None
        self.set_color(color, opacity)

    def set_color(self, color: QColor, opacity: float) -> None:
        fill = QColor(color)
        fill.setAlphaF(opacity)
        self.setBrush(QBrush(fill))
        self.setPen(QPen(QColor(color).darker(120), 1.5))

    def _in_resize_zone(self, pos: QPointF) -> bool:
        r = self.rect()
        corner = QRectF(r.right() - HANDLE_SIZE, r.bottom() - HANDLE_SIZE, HANDLE_SIZE * 2, HANDLE_SIZE * 2)
        return corner.contains(pos)

    def hoverMoveEvent(self, event):
        if self._in_resize_zone(event.pos()):
            self.setCursor(QCursor(Qt.SizeFDiagCursor))
        else:
            self.setCursor(QCursor(Qt.SizeAllCursor))
        super().hoverMoveEvent(event)

    def mousePressEvent(self, event):
        self._press_rect = QRectF(self.rect())
        self._press_pos = QPointF(self.pos())
        if self._in_resize_zone(event.pos()):
            self._resizing = True
            self.setSelected(True)
            event.accept()
        else:
            self._resizing = False
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._resizing:
            r = self.rect()
            new_w = max(MIN_RECT_SIZE, event.pos().x())
            new_h = max(MIN_RECT_SIZE, event.pos().y())
            r.setWidth(new_w)
            r.setHeight(new_h)
            self.prepareGeometryChange()
            self.setRect(r)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        was_resizing = self._resizing
        self._resizing = False
        if not was_resizing:
            super().mouseReleaseEvent(event)

        if self._press_rect is not None and self._press_pos is not None:
            rect_changed = self._press_rect != self.rect()
            pos_changed = self._press_pos != self.pos()
            if rect_changed or pos_changed:
                scene = self.scene()
                if isinstance(scene, PreviewScene):
                    scene.undo_stack.push(
                        MoveResizeRectCommand(
                            self, self._press_rect, self.rect(), self._press_pos, self.pos()
                        )
                    )
        self._press_rect = None
        self._press_pos = None


# --------------------------------------------------------------------------
# Undo/redo commands
# --------------------------------------------------------------------------

class AddRectCommand(QUndoCommand):
    def __init__(self, scene: "PreviewScene", rect_item: RedactionRectItem):
        super().__init__("Add redaction rectangle")
        self.scene_ref = scene
        self.rect_item = rect_item

    def redo(self):
        self.scene_ref.addItem(self.rect_item)
        self.scene_ref.rect_items.append(self.rect_item)
        self.scene_ref.rectangles_changed.emit()

    def undo(self):
        self.scene_ref.removeItem(self.rect_item)
        if self.rect_item in self.scene_ref.rect_items:
            self.scene_ref.rect_items.remove(self.rect_item)
        self.scene_ref.rectangles_changed.emit()


class DeleteRectCommand(QUndoCommand):
    def __init__(self, scene: "PreviewScene", rect_item: RedactionRectItem):
        super().__init__("Delete redaction rectangle")
        self.scene_ref = scene
        self.rect_item = rect_item

    def redo(self):
        self.scene_ref.removeItem(self.rect_item)
        if self.rect_item in self.scene_ref.rect_items:
            self.scene_ref.rect_items.remove(self.rect_item)
        self.scene_ref.rectangles_changed.emit()

    def undo(self):
        self.scene_ref.addItem(self.rect_item)
        self.scene_ref.rect_items.append(self.rect_item)
        self.scene_ref.rectangles_changed.emit()


class MoveResizeRectCommand(QUndoCommand):
    """Captures a before/after QRectF for a single rectangle edit."""

    def __init__(self, rect_item: RedactionRectItem, old_rect: QRectF, new_rect: QRectF, old_pos, new_pos):
        super().__init__("Edit redaction rectangle")
        self.rect_item = rect_item
        self.old_rect, self.new_rect = QRectF(old_rect), QRectF(new_rect)
        self.old_pos, self.new_pos = QPointF(old_pos), QPointF(new_pos)

    def redo(self):
        self.rect_item.setRect(self.new_rect)
        self.rect_item.setPos(self.new_pos)

    def undo(self):
        self.rect_item.setRect(self.old_rect)
        self.rect_item.setPos(self.old_pos)


@dataclass
class NormalizedRect:
    x: float
    y: float
    width: float
    height: float


class PreviewScene(QGraphicsScene):
    """Scene holding the page pixmap and all redaction rectangle items."""

    rectangles_changed = Signal()

    def __init__(self, undo_stack: QUndoStack, parent=None):
        super().__init__(parent)
        self.undo_stack = undo_stack
        self.page_item: QGraphicsPixmapItem | None = None
        self.rect_items: list[RedactionRectItem] = []
        self.page_width_pt = 0.0
        self.page_height_pt = 0.0
        self._draw_start: QPointF | None = None
        self._draw_preview: QGraphicsRectItem | None = None
        self.drawing_enabled = True
        self.rect_color = QColor(0, 0, 0)
        self.rect_opacity = 0.55

    def set_page(self, pixmap: QPixmap, page_width_pt: float, page_height_pt: float) -> None:
        """Replace the current page pixmap; keeps existing rect items in place."""
        if self.page_item:
            self.removeItem(self.page_item)
        self.page_item = QGraphicsPixmapItem(pixmap)
        self.page_item.setZValue(-1)
        self.addItem(self.page_item)
        self.setSceneRect(0, 0, pixmap.width(), pixmap.height())
        self.page_width_pt = page_width_pt
        self.page_height_pt = page_height_pt

    def mousePressEvent(self, event):
        if self.drawing_enabled and event.button() == Qt.LeftButton and self.itemAt(event.scenePos(), self.views()[0].transform()) is self.page_item:
            self._draw_start = event.scenePos()
            self._draw_preview = QGraphicsRectItem(QRectF(self._draw_start, self._draw_start))
            self._draw_preview.setPen(QPen(QColor(255, 0, 0), 1, Qt.DashLine))
            self.addItem(self._draw_preview)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._draw_preview is not None and self._draw_start is not None:
            rect = QRectF(self._draw_start, event.scenePos()).normalized()
            self._draw_preview.setRect(rect)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._draw_preview is not None:
            rect = self._draw_preview.rect()
            self.removeItem(self._draw_preview)
            self._draw_preview = None
            self._draw_start = None
            if rect.width() >= MIN_RECT_SIZE and rect.height() >= MIN_RECT_SIZE:
                item = RedactionRectItem(QRectF(0, 0, rect.width(), rect.height()), self.rect_color, self.rect_opacity)
                item.setPos(rect.topLeft())
                self.undo_stack.push(AddRectCommand(self, item))
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def delete_selected(self) -> None:
        for item in list(self.selectedItems()):
            if isinstance(item, RedactionRectItem):
                self.undo_stack.push(DeleteRectCommand(self, item))

    def clear_rectangles(self) -> None:
        for item in list(self.rect_items):
            self.removeItem(item)
        self.rect_items.clear()
        self.rectangles_changed.emit()

    def get_normalized_rectangles(self) -> list[NormalizedRect]:
        """Convert all rectangle items into normalized (0-1) page-fraction coordinates."""
        if not self.page_item:
            return []
        pw = self.page_item.pixmap().width()
        ph = self.page_item.pixmap().height()
        results = []
        for item in self.rect_items:
            scene_rect = item.mapRectToScene(item.rect())
            results.append(
                NormalizedRect(
                    x=scene_rect.x() / pw,
                    y=scene_rect.y() / ph,
                    width=scene_rect.width() / pw,
                    height=scene_rect.height() / ph,
                )
            )
        return results

    def load_normalized_rectangles(self, regions: list[NormalizedRect]) -> None:
        """Populate the scene with rectangles from normalized coordinates (e.g. loading a profile)."""
        if not self.page_item:
            return
        pw = self.page_item.pixmap().width()
        ph = self.page_item.pixmap().height()
        self.clear_rectangles()
        for region in regions:
            rect = QRectF(0, 0, region.width * pw, region.height * ph)
            item = RedactionRectItem(rect, self.rect_color, self.rect_opacity)
            item.setPos(region.x * pw, region.y * ph)
            self.addItem(item)
            self.rect_items.append(item)
        self.rectangles_changed.emit()


class PreviewView(QGraphicsView):
    """
    QGraphicsView wrapper providing zoom (in/out/fit-width/fit-page)
    and pan (space+drag, middle-mouse-drag, Ctrl+MouseWheel).
    """

    def __init__(self, scene: PreviewScene, parent=None):
        super().__init__(scene, parent)
        self.setRenderHints(self.renderHints())
        self.setDragMode(QGraphicsView.NoDrag)
        self._space_pressed = False
        self._zoom_factor = 1.0
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorUnderMouse)

    # --- zoom ---------------------------------------------------------

    def zoom_in(self, step: float = 1.15) -> None:
        self._apply_zoom(step)

    def zoom_out(self, step: float = 1.15) -> None:
        self._apply_zoom(1 / step)

    def _apply_zoom(self, factor: float) -> None:
        self._zoom_factor *= factor
        self.scale(factor, factor)

    def fit_width(self) -> None:
        if not self.scene().sceneRect().isEmpty():
            scene_rect = self.scene().sceneRect()
            viewport_width = self.viewport().width()
            factor = viewport_width / scene_rect.width()
            self.resetTransform()
            self.scale(factor, factor)
            self._zoom_factor = factor

    def fit_page(self) -> None:
        if not self.scene().sceneRect().isEmpty():
            self.fitInView(self.scene().sceneRect(), Qt.KeepAspectRatio)
            self._zoom_factor = self.transform().m11()

    def wheelEvent(self, event):
        if event.modifiers() & Qt.ControlModifier:
            factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
            self._apply_zoom(factor)
            event.accept()
        else:
            super().wheelEvent(event)

    # --- pan ------------------------------------------------------------

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Space and not event.isAutoRepeat():
            self._space_pressed = True
            self.setDragMode(QGraphicsView.ScrollHandDrag)
        super().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key_Space and not event.isAutoRepeat():
            self._space_pressed = False
            self.setDragMode(QGraphicsView.NoDrag)
        super().keyReleaseEvent(event)
