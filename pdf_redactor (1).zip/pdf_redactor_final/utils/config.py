"""
utils/config.py

Application preferences persisted as JSON. Handles:
    - default output folder
    - recent files list
    - theme (light/dark)
    - autosave-profiles flag
    - active language code (language-ready, not translated by default)

No global mutable state: callers own an AppConfig instance
(typically one, created in main.py and passed down via composition).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

from utils.logger import get_logger

logger = get_logger(__name__)

DEFAULT_CONFIG_DIR = Path.home() / ".pdf_redactor"
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.json"
MAX_RECENT_FILES = 15


@dataclass
class AppConfig:
    """In-memory representation of user preferences."""

    theme: str = "dark"
    default_output_folder: str = str(Path.home() / "PDF_Redactor_Output")
    recent_files: list[str] = field(default_factory=list)
    autosave_profiles: bool = True
    language: str = "en"
    last_profile: str | None = None
    default_rename_mode: str = "suffix"  # "suffix" | "overwrite" | "custom"
    default_suffix: str = "_redacted"

    # --- persistence -----------------------------------------------------

    @classmethod
    def load(cls, path: Path | None = None) -> "AppConfig":
        """
        Load configuration from disk, falling back to defaults if the
        file is missing or malformed (never raises to the caller).
        """
        path = path or DEFAULT_CONFIG_FILE
        if not path.exists():
            logger.info("No config file found at %s, using defaults.", path)
            return cls()

        try:
            data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
            known_fields = {f for f in cls.__dataclass_fields__}
            filtered = {k: v for k, v in data.items() if k in known_fields}
            return cls(**filtered)
        except (json.JSONDecodeError, OSError, TypeError) as exc:
            logger.warning("Failed to load config (%s); using defaults.", exc)
            return cls()

    def save(self, path: Path | None = None) -> None:
        """Persist configuration to disk as JSON."""
        path = path or DEFAULT_CONFIG_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        except OSError as exc:
            logger.error("Failed to save config to %s: %s", path, exc)

    # --- convenience mutators ---------------------------------------------

    def add_recent_file(self, filepath: str) -> None:
        """Push a file to the front of the recent-files list, deduplicated."""
        if filepath in self.recent_files:
            self.recent_files.remove(filepath)
        self.recent_files.insert(0, filepath)
        self.recent_files = self.recent_files[:MAX_RECENT_FILES]
