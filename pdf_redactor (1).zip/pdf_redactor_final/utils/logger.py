"""
utils/logger.py

Centralized logging configuration for PDF Redactor.

Provides a single `get_logger()` factory so every module logs to the
same rotating file handler and console handler, with a consistent
format. No global mutable state beyond the standard library's own
logging registry (which is the accepted pattern for Python logging).
"""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path


DEFAULT_LOG_DIR = Path.home() / ".pdf_redactor" / "logs"
DEFAULT_LOG_FILE = DEFAULT_LOG_DIR / "pdf_redactor.log"
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def configure_logging(log_dir: Path | None = None, level: int = logging.INFO) -> None:
    """
    Configure the root 'pdf_redactor' logger once for the whole application.

    :param log_dir: Directory to write log files into. Defaults to
        ~/.pdf_redactor/logs. Created if it doesn't exist.
    :param level: Logging level for both handlers.
    """
    log_dir = log_dir or DEFAULT_LOG_DIR
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "pdf_redactor.log"

    root = logging.getLogger("pdf_redactor")
    if root.handlers:
        # Already configured (e.g. re-entrant call); avoid duplicate handlers.
        return

    root.setLevel(level)

    formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

    file_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(level)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(level)

    root.addHandler(file_handler)
    root.addHandler(console_handler)


def get_logger(name: str) -> logging.Logger:
    """
    Return a module-level logger namespaced under 'pdf_redactor'.

    :param name: Typically __name__ of the calling module.
    :return: A configured Logger instance.
    """
    if not name.startswith("pdf_redactor"):
        name = f"pdf_redactor.{name}"
    return logging.getLogger(name)
